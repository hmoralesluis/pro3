@extends('app')

@section('content')
    @yield('top_header')
    <div id="top-banner-and-menu">
        <div class="container">
            <div class="col-xs-12 col-sm-4 col-md-3 sidemenu-holder">
                @include('shop.sections.left')
            </div><!-- /.sidemenu-holder -->

            <div class="col-xs-12 col-sm-8 col-md-9 homebanner-holder">
                @yield('main_content')
            </div><!-- /.homebanner-holder -->


        </div><!-- /.container -->
    </div><!-- /#top-banner-and-menu -->


    @include('shop.sections.brands_slider')

    @include('shop.sections.footer')
@endsection