<div id="products-tab" class="wow fadeInUp color-bg">
    <div class="container">

        <div class="tab-holder">
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" >
                <li class="active"><a href="#featured" data-toggle="tab">Nuevos productos</a></li>
                <li><a href="#new-arrivals" data-toggle="tab">Mas visitados</a></li>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <div class="tab-pane active" id="featured">
                    <div class="product-grid-holder">
                        <div class="row no-margin">
                            @foreach($lasted as $p)
                                <div class="col-sm-4 col-md-3 no-margin product-item-holder hover">
                                    <div class="product-item">
                                        <div class="ribbon blue"><span>new!</span></div>
                                        <div class="image">
                                            <img  class="img-responsive" src="{{url('catalog/images/' . $p->image)}}" alt="" />
                                        </div>
                                        <div class="body">
                                            <div class="label-discount clear"></div>
                                            <div class="title">
                                                <a href="{{url('product/details/'. $p->id)}}">{{$p->part_number}}</a>
                                            </div>
                                            <div class="brand">{{$p->mark}}</div>
                                        </div>

                                        <div class="hover-area">
                                            <div class="add-cart-button">
                                                <a href="{{url('product/details/'. $p->id)}}" class="le-button">Detalles</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>

                <div class="tab-pane" id="new-arrivals">
                     <div class="product-grid-holder">
                         <div class="row no-margin">
                            @foreach($most_visit as $p)
                                <div class="col-sm-3 col-md-3 no-margin product-item-holder hover">
                                    <div class="product-item">
                                        <div class="image">
                                            <img  class="img-responsive" src="{{url('catalog/images/' . $p->image)}}" alt="" />
                                        </div>
                                        <div class="body">
                                            <div class="label-discount clear"></div>
                                            <div class="title">
                                                <a href="{{url('product/details/'. $p->id)}}">{{$p->part_number}}</a>
                                            </div>
                                            <div class="brand">{{$p->mark}}</div>
                                        </div>

                                        <div class="hover-area">
                                            <div class="add-cart-button">
                                                <a href="single-product.html" class="le-button">Detalles</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                         </div>
                     </div>


                </div>
            </div>
        </div>
    </div>
</div>