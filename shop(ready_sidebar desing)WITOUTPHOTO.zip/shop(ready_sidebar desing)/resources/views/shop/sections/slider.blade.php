
    <!-- ========================================== SECTION � HERO ========================================= -->
    <div id="hero">
        <div id="owl-main" class="owl-carousel owl-inner-nav owl-ui-sm">

            <div class="item" style="background-image: url(shop/assets/images/sliders/slider1.jpg);">
                <div class="container-fluid">
                    <div class="caption vertical-center text-left">
                        <div class="big-text fadeInDown-1">
                            Lo nuevo de <span class="big"><span class="sign"></span>{{$slide[0]->mark}}</span>
                        </div>

                        <div class="excerpt fadeInDown-2">
                            <br>
                            disponible
                            {{$slide[0]->part_number}}<br>
                            100% seguro </br>
                        </div>
                        <div class="small fadeInDown-2">

                        </div>
                        <div class="button-holder fadeInDown-3">
                            <a href="{{url('product/details/'. $slide[0]->id)}}" class="big le-button ">Detalles</a>
                        </div>
                    </div><!-- /.caption -->
                </div><!-- /.container-fluid -->
            </div><!-- /.item -->

            <div class="item" style="background-image: url(shop/assets/images/sliders/slider2.jpg);">
                <div class="container-fluid">
                    <div class="caption vertical-center text-left">
                        <div class="big-text fadeInDown-1">
                            Lo nuevo de <span class="big"><span class="sign"></span>{{$slide[1]->mark}}</span>
                        </div>

                        <div class="excerpt fadeInDown-2">
                            <br>
                            disponible
                            {{$slide[1]->part_number}}<br>
                            100% seguro </br>
                        </div>
                        <div class="small fadeInDown-2">

                        </div>
                        <div class="button-holder fadeInDown-3">
                            <a href="{{url('product/details/'. $slide[1]->id)}}" class="big le-button ">Detalles</a>
                        </div>
                    </div><!-- /.caption -->
                </div><!-- /.container-fluid -->
            </div><!-- /.item -->


            <div class="item" style="background-image: url(shop/assets/images/sliders/slider3.jpg);">
                <div class="container-fluid">
                    <div class="caption vertical-center text-left">
                        <div class="big-text fadeInDown-1">
                            Lo nuevo de <span class="big"><span class="sign"></span>{{$slide[2]->mark}}</span>
                        </div>

                        <div class="excerpt fadeInDown-2">
                            <br>
                            disponible
                            {{$slide[2]->part_number}}<br>
                            100% seguro </br>
                        </div>
                        <div class="small fadeInDown-2">

                        </div>
                        <div class="button-holder fadeInDown-3">
                            <a href="{{url('product/details/'. $slide[2]->id)}}" class="big le-button ">Detalles</a>
                        </div>
                    </div><!-- /.caption -->
                </div><!-- /.container-fluid -->
            </div><!-- /.item -->

        </div><!-- /.owl-carousel -->
    </div>

    <!-- ========================================= SECTION � HERO : END ========================================= -->



